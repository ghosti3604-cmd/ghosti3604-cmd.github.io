/**
 * IQChat - Main Application Controller & UI Orchestrator
 */

import { listenToAuthState, registerUser, loginUser, logoutUser } from './auth.js';
import { startPresenceSystem, stopPresenceSystem, subscribeToUsersPresence, formatUserPresenceText } from './presence.js';
import { 
  setActiveChatPeer, 
  getActiveChatPeer, 
  subscribeToMessages, 
  sendTextMessage, 
  sendImageMessage, 
  processImageFile, 
  formatMessageTime 
} from './chat.js';
import { saveFirebaseConfig, clearFirebaseConfig, isFirebaseReady, getSavedFirebaseConfig } from './firebase-config.js';

// DOM Elements
const firebaseSetupScreen = document.getElementById('firebaseSetupScreen');
const authScreen = document.getElementById('authScreen');
const usersScreen = document.getElementById('usersScreen');
const chatScreen = document.getElementById('chatScreen');

const userHeaderProfile = document.getElementById('userHeaderProfile');
const headerAvatar = document.getElementById('headerAvatar');
const logoutBtn = document.getElementById('logoutBtn');

const tabLoginBtn = document.getElementById('tabLoginBtn');
const tabRegisterBtn = document.getElementById('tabRegisterBtn');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const authAlert = document.getElementById('authAlert');

const avatarPicker = document.getElementById('avatarPicker');
const customAvatarBtn = document.getElementById('customAvatarBtn');
const customAvatarInput = document.getElementById('customAvatarInput');
let selectedAvatarUrl = 'https://api.dicebear.com/7.x/avataaars/svg?seed=IQUser1';

const searchUsersInput = document.getElementById('searchUsersInput');
const filterPills = document.querySelectorAll('.pill-btn');
const usersList = document.getElementById('usersList');
const onlineHorizontalList = document.getElementById('onlineHorizontalList');
const totalUsersCount = document.getElementById('totalUsersCount');
const onlineUsersCount = document.getElementById('onlineUsersCount');

const closeChatBtn = document.getElementById('closeChatBtn');
const chatTargetAvatar = document.getElementById('chatTargetAvatar');
const chatTargetStatus = document.getElementById('chatTargetStatus');
const chatTargetName = document.getElementById('chatTargetName');
const chatTargetSubtext = document.getElementById('chatTargetSubtext');
const messagesContainer = document.getElementById('messagesContainer');
const emptyChatNotice = document.getElementById('emptyChatNotice');

const chatForm = document.getElementById('chatForm');
const messageTextInput = document.getElementById('messageTextInput');
const attachImageBtn = document.getElementById('attachImageBtn');
const imageFileInput = document.getElementById('imageFileInput');
const imagePreviewOverlay = document.getElementById('imagePreviewOverlay');
const previewImageElement = document.getElementById('previewImageElement');
const cancelImagePreviewBtn = document.getElementById('cancelImagePreviewBtn');
const sendImagePreviewBtn = document.getElementById('sendImagePreviewBtn');
let pendingImageBase64 = null;

const lightboxModal = document.getElementById('lightboxModal');
const lightboxImage = document.getElementById('lightboxImage');
const closeLightboxBtn = document.getElementById('closeLightboxBtn');

const configFirebaseBtn = document.getElementById('configFirebaseBtn');
const firebaseModal = document.getElementById('firebaseModal');
const closeFirebaseModalBtn = document.getElementById('closeFirebaseModalBtn');
const firebaseConfigForm = document.getElementById('firebaseConfigForm');
const clearConfigBtn = document.getElementById('clearConfigBtn');
const initialFirebaseSetupForm = document.getElementById('initialFirebaseSetupForm');

// App State
let me = null;
let allUsersCache = [];
let currentFilter = 'all';
let activeMessagesUnsubscribe = null;
let activeUsersUnsubscribe = null;

// Initialize Application
document.addEventListener('DOMContentLoaded', async () => {
  setupEventListeners();
  checkAppSetup();
});

function checkAppSetup() {
  const isReady = isFirebaseReady();
  if (!isReady) {
    const saved = getSavedFirebaseConfig();
    if (saved) {
      document.getElementById('initApiKey').value = saved.apiKey || '';
      document.getElementById('initAuthDomain').value = saved.authDomain || '';
      document.getElementById('initProjectId').value = saved.projectId || '';
      document.getElementById('initStorageBucket').value = saved.storageBucket || '';
      document.getElementById('initMessagingSenderId').value = saved.messagingSenderId || '';
      document.getElementById('initAppId').value = saved.appId || '';
    }
    showScreen(firebaseSetupScreen);
    return;
  }

  // Listen to Auth State
  listenToAuthState((user) => {
    if (user) {
      onUserLoggedIn(user);
    } else {
      userHeaderProfile.style.display = 'none';
      showScreen(authScreen);
    }
  });
}

function onUserLoggedIn(user) {
  me = user;
  headerAvatar.src = user.avatar || selectedAvatarUrl;
  userHeaderProfile.style.display = 'flex';

  startPresenceSystem(user.id);
  showScreen(usersScreen);

  if (activeUsersUnsubscribe) activeUsersUnsubscribe();
  activeUsersUnsubscribe = subscribeToUsersPresence(user.id, (users) => {
    allUsersCache = users;
    renderUsersList();
  });
}

/**
 * Screen Switcher Helper
 */
function showScreen(targetScreen) {
  [firebaseSetupScreen, authScreen, usersScreen, chatScreen].forEach(s => s.classList.remove('active'));
  targetScreen.classList.add('active');
}

/**
 * Setup All Event Listeners
 */
function setupEventListeners() {
  // Initial Firebase Setup Form
  initialFirebaseSetupForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const config = {
      apiKey: document.getElementById('initApiKey').value.trim(),
      authDomain: document.getElementById('initAuthDomain').value.trim(),
      projectId: document.getElementById('initProjectId').value.trim(),
      storageBucket: document.getElementById('initStorageBucket').value.trim(),
      messagingSenderId: document.getElementById('initMessagingSenderId').value.trim(),
      appId: document.getElementById('initAppId').value.trim()
    };
    saveFirebaseConfig(config);
  });

  // Auth Tab Switching (Login / Register)
  tabLoginBtn.addEventListener('click', () => {
    tabLoginBtn.classList.add('active');
    tabRegisterBtn.classList.remove('active');
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
    loginForm.classList.add('active');
    registerForm.classList.remove('active');
    hideAuthAlert();
  });

  tabRegisterBtn.addEventListener('click', () => {
    tabRegisterBtn.classList.add('active');
    tabLoginBtn.classList.remove('active');
    registerForm.style.display = 'block';
    loginForm.style.display = 'none';
    registerForm.classList.add('active');
    loginForm.classList.remove('active');
    hideAuthAlert();
  });

  // Avatar Picker Selection
  avatarPicker.addEventListener('click', (e) => {
    const opt = e.target.closest('.avatar-opt');
    if (opt) {
      document.querySelectorAll('.avatar-opt').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      selectedAvatarUrl = opt.getAttribute('data-avatar');
    }
  });

  // Custom Avatar Upload
  customAvatarBtn.addEventListener('click', () => customAvatarInput.click());
  customAvatarInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        const base64 = await processImageFile(file);
        selectedAvatarUrl = base64;
        
        const newOpt = document.createElement('div');
        newOpt.className = 'avatar-opt selected';
        newOpt.setAttribute('data-avatar', base64);
        newOpt.innerHTML = `<img src="${base64}">`;
        
        document.querySelectorAll('.avatar-opt').forEach(o => o.classList.remove('selected'));
        avatarPicker.insertBefore(newOpt, customAvatarBtn);
      } catch (err) {
        showAuthAlert('فشل معالجة الصورة الشخصية', 'error');
      }
    }
  });

  // Password Visibility Toggle
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const input = document.getElementById(targetId);
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="fa-regular fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="fa-regular fa-eye"></i>';
      }
    });
  });

  // Register Form Submit
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideAuthAlert();

    const submitBtn = document.getElementById('registerSubmitBtn');
    const originalText = submitBtn.innerHTML;

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> جاري إنشاء الحساب...';

    try {
      const name = document.getElementById('regName').value.trim();
      const email = document.getElementById('regEmail').value.trim();
      const password = document.getElementById('regPassword').value;

      const res = await registerUser({ name, email, password, avatar: selectedAvatarUrl });
      if (!res.success) {
        showAuthAlert(res.error, 'error');
      }
    } catch (err) {
      showAuthAlert('حدث خطأ: ' + (err.message || err), 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });

  // Login Form Submit
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideAuthAlert();

    const submitBtn = document.getElementById('loginSubmitBtn');
    const originalText = submitBtn.innerHTML;

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> جاري تسجيل الدخول...';

    try {
      const email = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value;

      const res = await loginUser({ email, password });
      if (!res.success) {
        showAuthAlert(res.error, 'error');
      }
    } catch (err) {
      showAuthAlert('حدث خطأ: ' + (err.message || err), 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });

  // INSTANT LOGOUT BUTTON
  logoutBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (me) {
      stopPresenceSystem(me.id);
    }
    me = null;

    // Instant UI switch to Auth Screen
    userHeaderProfile.style.display = 'none';
    showScreen(authScreen);

    // Perform Firebase signOut asynchronously
    await logoutUser();
  });

  // Search Input & Filter Pills
  searchUsersInput.addEventListener('input', renderUsersList);
  filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
      filterPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentFilter = pill.getAttribute('data-filter');
      renderUsersList();
    });
  });

  // Close Active Chat
  closeChatBtn.addEventListener('click', () => {
    if (activeMessagesUnsubscribe) activeMessagesUnsubscribe();
    setActiveChatPeer(null);
    showScreen(usersScreen);
  });

  // Image Attachment Trigger & Preview
  attachImageBtn.addEventListener('click', () => imageFileInput.click());
  imageFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        pendingImageBase64 = await processImageFile(file);
        previewImageElement.src = pendingImageBase64;
        imagePreviewOverlay.style.display = 'block';
      } catch (err) {
        alert('فشل اختيار الصورة');
      }
    }
  });

  cancelImagePreviewBtn.addEventListener('click', () => {
    pendingImageBase64 = null;
    imagePreviewOverlay.style.display = 'none';
    imageFileInput.value = '';
  });

  sendImagePreviewBtn.addEventListener('click', async () => {
    const peer = getActiveChatPeer();
    if (peer && pendingImageBase64) {
      await sendImageMessage(me.id, peer.id, pendingImageBase64);
      pendingImageBase64 = null;
      imagePreviewOverlay.style.display = 'none';
      imageFileInput.value = '';
    }
  });

  // Chat Form Submit (Text Message)
  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = messageTextInput.value;
    const peer = getActiveChatPeer();

    if (text && text.trim() && peer) {
      messageTextInput.value = '';
      await sendTextMessage(me.id, peer.id, text);
    }
  });

  // Lightbox Close
  closeLightboxBtn.addEventListener('click', () => lightboxModal.style.display = 'none');
  lightboxModal.addEventListener('click', (e) => {
    if (e.target === lightboxModal) lightboxModal.style.display = 'none';
  });

  // Firebase Config Modal Controls
  configFirebaseBtn.addEventListener('click', () => {
    const saved = getSavedFirebaseConfig();
    if (saved) {
      document.getElementById('fbApiKey').value = saved.apiKey || '';
      document.getElementById('fbAuthDomain').value = saved.authDomain || '';
      document.getElementById('fbProjectId').value = saved.projectId || '';
      document.getElementById('fbStorageBucket').value = saved.storageBucket || '';
      document.getElementById('fbMessagingSenderId').value = saved.messagingSenderId || '';
      document.getElementById('fbAppId').value = saved.appId || '';
    }
    firebaseModal.style.display = 'flex';
  });

  closeFirebaseModalBtn.addEventListener('click', () => firebaseModal.style.display = 'none');
  
  firebaseConfigForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const config = {
      apiKey: document.getElementById('fbApiKey').value.trim(),
      authDomain: document.getElementById('fbAuthDomain').value.trim(),
      projectId: document.getElementById('fbProjectId').value.trim(),
      storageBucket: document.getElementById('fbStorageBucket').value.trim(),
      messagingSenderId: document.getElementById('fbMessagingSenderId').value.trim(),
      appId: document.getElementById('fbAppId').value.trim()
    };
    saveFirebaseConfig(config);
  });

  clearConfigBtn.addEventListener('click', () => clearFirebaseConfig());
}

/**
 * Render Live Firestore Users List (With Glowing Green Dots)
 */
function renderUsersList() {
  const queryText = searchUsersInput.value.toLowerCase().trim();

  let filtered = allUsersCache.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(queryText) || (u.email && u.email.toLowerCase().includes(queryText));
    if (currentFilter === 'online') {
      return matchesSearch && u.isOnline;
    }
    return matchesSearch;
  });

  totalUsersCount.textContent = allUsersCache.length;
  const onlineCount = allUsersCache.filter(u => u.isOnline).length;
  onlineUsersCount.textContent = onlineCount;

  // 1. Render Horizontal Online Bar
  const onlineUsers = allUsersCache.filter(u => u.isOnline);
  if (onlineUsers.length === 0) {
    onlineHorizontalList.innerHTML = `<div style="font-size:0.78rem; color:var(--text-dim); padding:4px;">لا يوجد مستخدمون متصلون حالياً في IQChat</div>`;
  } else {
    onlineHorizontalList.innerHTML = onlineUsers.map(user => `
      <div class="horizontal-user-card" data-user-id="${user.id}">
        <div class="avatar-wrapper">
          <img src="${user.avatar}" alt="${user.name}">
          <span class="status-indicator online"></span>
        </div>
        <span>${user.name}</span>
      </div>
    `).join('');
  }

  // 2. Render Users List Items
  if (filtered.length === 0) {
    usersList.innerHTML = `<div style="text-align:center; padding:30px; color:var(--text-dim); font-size:0.9rem;">لا توجد حسابات مسجلة حالياً. قم بإنشاء حسابات أخرى عبر الموبايل/المتصفح لظهورها مباشرة!</div>`;
    return;
  }

  usersList.innerHTML = filtered.map(user => {
    const statusClass = user.isOnline ? 'online' : 'offline';
    const presenceText = formatUserPresenceText(user);

    return `
      <div class="user-item" data-user-id="${user.id}">
        <div class="avatar-wrapper">
          <img src="${user.avatar}" alt="${user.name}">
          <span class="status-indicator ${statusClass}"></span>
        </div>
        <div class="user-item-info">
          <div class="user-item-header">
            <h4 class="user-item-name">${user.name}</h4>
            <span class="user-item-time">${user.isOnline ? 'أونلاين' : ''}</span>
          </div>
          <p class="user-item-lastmsg">
            <i class="fa-regular fa-comment-dots" style="font-size:0.75rem;"></i>
            <span>${presenceText}</span>
          </p>
        </div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('[data-user-id]').forEach(el => {
    el.addEventListener('click', () => {
      const userId = el.getAttribute('data-user-id');
      const targetUser = allUsersCache.find(u => u.id === userId);
      if (targetUser) {
        openChatWithUser(targetUser);
      }
    });
  });
}

/**
 * Open Direct Chat Screen
 */
function openChatWithUser(targetUser) {
  setActiveChatPeer(targetUser);

  chatTargetAvatar.src = targetUser.avatar;
  chatTargetName.textContent = targetUser.name;
  
  if (targetUser.isOnline) {
    chatTargetStatus.className = 'status-indicator online';
    chatTargetSubtext.textContent = 'متصل الآن';
    chatTargetSubtext.style.color = 'var(--status-online)';
  } else {
    chatTargetStatus.className = 'status-indicator offline';
    chatTargetSubtext.textContent = formatUserPresenceText(targetUser);
    chatTargetSubtext.style.color = 'var(--text-muted)';
  }

  showScreen(chatScreen);

  if (activeMessagesUnsubscribe) activeMessagesUnsubscribe();
  activeMessagesUnsubscribe = subscribeToMessages(me.id, targetUser.id, (messages) => {
    renderMessagesFeed(messages);
  });
}

/**
 * Render Chat Messages Feed
 */
function renderMessagesFeed(messages) {
  if (!messages || messages.length === 0) {
    messagesContainer.innerHTML = '';
    messagesContainer.appendChild(emptyChatNotice);
    emptyChatNotice.style.display = 'block';
    return;
  }

  emptyChatNotice.style.display = 'none';

  messagesContainer.innerHTML = messages.map(msg => {
    const isSentByMe = msg.senderId === me.id;
    const wrapperClass = isSentByMe ? 'sent' : 'received';
    const timeStr = formatMessageTime(msg.timestamp);

    let contentHtml = '';
    if (msg.type === 'image' || msg.imageUrl) {
      contentHtml = `
        <div class="message-image-attachment" onclick="window.openLightbox('${msg.imageUrl}')">
          <img src="${msg.imageUrl}" alt="صورة مرفقة" loading="lazy">
        </div>
      `;
    }

    if (msg.text) {
      contentHtml += `<div class="message-text">${escapeHtml(msg.text)}</div>`;
    }

    return `
      <div class="message-bubble-wrapper ${wrapperClass}">
        <div class="message-bubble">
          ${contentHtml}
          <div class="message-info">
            <span>${timeStr}</span>
            ${isSentByMe ? '<i class="fa-solid fa-check-double" style="font-size:0.7rem; color:#A7F3D0;"></i>' : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');

  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

window.openLightbox = function(url) {
  lightboxImage.src = url;
  lightboxModal.style.display = 'flex';
};

function showAuthAlert(msg, type = 'error') {
  authAlert.textContent = msg;
  authAlert.className = `auth-alert ${type}`;
  authAlert.style.display = 'block';
  authAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function hideAuthAlert() {
  authAlert.style.display = 'none';
}

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
